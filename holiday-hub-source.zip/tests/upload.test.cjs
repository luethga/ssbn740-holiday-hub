const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');

function environment(now = '2026-11-21T16:00:00Z') {
  const properties = { GREETING_FOLDER_ID: 'private-greetings', LANDING_VIDEO_ID: 'private_video_address', RELEASE_AT: '2026-12-25T07:40:00-05:00' };
  const created = [], receipts = new Map(), cache = new Map();
  let releases = 0;
  class Clock extends Date { constructor(...args) { super(...(args.length ? args : [now])); } static now() { return new Date(now).getTime(); } }
  const context = vm.createContext({
    Date: Clock, console,
    UPLOAD_HTML_: 'Uploader form',
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => properties[k] ?? null, setProperty: (k,v) => { properties[k] = v; } }) },
    CacheService: { getScriptCache: () => ({ get: k => cache.get(k), put: (k,v) => cache.set(k,v) }) },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => { releases++; } }) },
    Utilities: { formatDate: (_,__,format) => format === 'yyyy-MM-dd' ? '2026-11-21' : '2026-11-21-11', base64Encode: value => Buffer.from(value).toString('base64') },
    UrlFetchApp: { fetch: () => ({ getResponseCode:()=>200, getBlob:()=>({ getBytes:()=>[1,2,3] }) }) },
    ScriptApp: { getOAuthToken:()=> 'server-only-token' },
    Drive: { Files: {
      list: options => { const match = options.q.match(/value='([^']+)'/); return { files: match && receipts.has(match[1]) ? [{id: receipts.get(match[1])}] : [] }; },
      create: (metadata,blob) => { created.push({metadata,blob}); const id = 'new-file-' + created.length; if(metadata.appProperties) receipts.set(metadata.appProperties.receipt,id); return {id}; },
      get: id => ({ id, name: 'Private greetings', webViewLink: 'https://drive.google.com/drive/folders/' + id })
    } },
    HtmlService: { XFrameOptionsMode: {ALLOWALL:'ALLOWALL'}, createHtmlOutput: html => ({html,setTitle(){return this;},setXFrameOptionsMode(){return this;}}) }
  });
  vm.runInContext(source, context);
  const video = {getBytes:()=>[0,0,0,24,102,116,121,112,105,115,111,109],getContentType:()=> 'video/mp4',setName(){return this;}};
  const form = { sender:'Test Family', recipient:'Whole Boat', consent:'yes', duration:'8', requestId:'12345678-1234-1234-1234-123456789abc', startedAt:String(Clock.now()-5000), video };
  return {context,form,created,cache,properties,get releases(){return releases;}};
}

test('accepted clips are stored in the private destination without sharing permissions', () => {
  const e=environment(), receipt=e.context.uploadGreeting(e.form);
  assert.equal(receipt.ok,true); assert.equal(e.created.length,1);
  assert.deepEqual(Array.from(e.created[0].metadata.parents),['private-greetings']);
  assert.equal(e.created[0].metadata.permissions,undefined);
  assert.equal(receipt.id,undefined); assert.equal(receipt.url,undefined); assert.equal(e.releases,1);
});
test('retries after cache expiry do not create duplicate clips', () => {
  const e=environment(); e.context.uploadGreeting(e.form); e.cache.clear();
  assert.equal(e.context.uploadGreeting(e.form).ok,true); assert.equal(e.created.length,1);
});
for (const [name, mutate, pattern] of [
  ['missing consent', f=>f.consent='', /confirm permission/],
  ['long video', f=>f.duration='15.5', /15 seconds/],
  ['invalid duration', f=>f.duration='Infinity', /15 seconds/],
  ['honeypot', f=>f.website='spam', /refresh/],
  ['missing sender', f=>f.sender='', /family name/],
  ['invalid request id', f=>f.requestId="x' or true", /refresh/],
  ['invalid video signature', f=>f.video={getBytes:()=>[1,2,3,4,5,6,7,8],getContentType:()=> 'video/mp4'}, /recognized/],
  ['oversized video', f=>f.video={getBytes:()=>({length:26*1024*1024})}, /25 MB/]
]) test('rejects '+name+' before writing to Drive', () => {const e=environment();mutate(e.form);assert.throws(()=>e.context.uploadGreeting(e.form),pattern);assert.equal(e.created.length,0);});
test('daily volume limit prevents additional writes', () => {
  const e=environment();e.properties.UPLOAD_USAGE=JSON.stringify({day:'2026-11-21',bytes:500*1024*1024});
  assert.throws(()=>e.context.uploadGreeting(e.form),/busy today/);assert.equal(e.created.length,0);assert.equal(e.releases,1);
});
test('landing address stays server-side before Christmas release', () => {
  const e=environment('2026-12-25T12:39:59Z'), response=e.context.doGet({parameter:{view:'landing'}});
  assert.match(response.html,/7:40 a.m. Eastern/);assert.doesNotMatch(response.html,/private_video_address/);
});
test('landing releases at 7:40 Eastern, using server time', () => {
  const e=environment('2026-12-25T12:40:00Z');
  const html=e.context.doGet({parameter:{view:'landing'}}).html;
  assert.match(html,/data:video\/mp4;base64,AQID/);
  assert.doesNotMatch(html,/private_video_address|server-only-token/);
});
test('site has no browser persistence or Firebase dependencies, and inline JavaScript parses', () => {
  const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.doesNotMatch(html,/indexedDB|localStorage|sessionStorage|firebase/);
  for(const match of html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)) new vm.Script(match[1]);
  const upload=fs.readFileSync(path.join(root,'google-apps-script/Upload.html'),'utf8');
  for(const match of upload.matchAll(/<script>([\s\S]*?)<\/script>/g)) new vm.Script(match[1]);
});
