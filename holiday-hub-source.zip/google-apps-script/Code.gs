// Private, upload-only storage for the SSBN740 holiday hub.
// Requires the Advanced Drive v3 service and the drive.file scope only.
const MAX_VIDEO_BYTES_ = 25 * 1024 * 1024;
const MAX_DAILY_BYTES_ = 500 * 1024 * 1024;

function doGet(event) {
  if (event && event.parameter && event.parameter.view === 'landing') return landingPage_();
  return HtmlService.createHtmlOutput(UPLOAD_HTML_)
    .setTitle('Blue Crew Private Video Greetings')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// The browser never receives the landing-video address before the release time.
function landingPage_() {
  const props = PropertiesService.getScriptProperties();
  const release = new Date(props.getProperty('RELEASE_AT') || '2026-12-25T07:40:00-05:00');
  const videoId = props.getProperty('LANDING_VIDEO_ID') || '';
  const released = Number.isFinite(release.getTime()) && Date.now() >= release.getTime();
  let body = '<main style="padding:36px;text-align:center"><h2>Santa’s landing is on the way</h2><p>The video opens December 25 at 7:40 a.m. Eastern (Kings Bay time).</p></main><script>setTimeout(function(){location.reload()},30000)</script>';
  if (released && /^[a-zA-Z0-9_-]{10,100}$/.test(videoId)) {
    try {
      const response = UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/' + encodeURIComponent(videoId) + '?alt=media', {
        headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true
      });
      if (response.getResponseCode() !== 200) throw new Error('Video not available.');
      const data = Utilities.base64Encode(response.getBlob().getBytes());
      body = '<video title="Santa lands aboard USS Rhode Island" controls playsinline autoplay style="position:fixed;inset:0;width:100%;height:100%;background:black" src="data:video/mp4;base64,' + data + '"></video>';
    } catch (_) {
      body = '<main style="padding:36px;text-align:center"><h2>Santa’s landing video</h2><p>The video could not load just now. Please refresh in a moment.</p></main>';
    }
  }
  return HtmlService.createHtmlOutput('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;background:#030813;color:white;font-family:Arial,sans-serif}</style></head><body>' + body + '</body></html>')
    .setTitle('Santa’s Christmas Landing')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// Run once in the editor. This function is unavailable to website visitors.
function setupStorage_() {
  const props = PropertiesService.getScriptProperties();
  let folderId = props.getProperty('GREETING_FOLDER_ID');
  if (!folderId) {
    const folder = Drive.Files.create({
      name: 'SSBN740 Incoming Holiday Greetings',
      mimeType: 'application/vnd.google-apps.folder',
      description: 'Private family video greetings. Uploaded clips are never publicly shared.'
    }, null, { fields: 'id' });
    folderId = folder.id;
    props.setProperty('GREETING_FOLDER_ID', folderId);
  }
  const folder = Drive.Files.get(folderId, { fields: 'id,name,webViewLink' });
  console.log(JSON.stringify(folder));
  return folder;
}

// The only visitor-callable storage operation. No listing or download API exists.
function uploadGreeting(form) {
  if (!form || form.website) throw new Error('Please refresh the form and try again.');
  const folderId = PropertiesService.getScriptProperties().getProperty('GREETING_FOLDER_ID');
  if (!folderId) throw new Error('Video collection is not open yet. Please try again later.');
  const sender = String(form.sender || '').trim();
  const recipient = String(form.recipient || 'Whole Boat — Blue Crew').trim();
  if (!sender || sender.length > 100 || !recipient || recipient.length > 100) {
    throw new Error('Enter a family name and a recipient, each under 100 characters.');
  }
  if (form.consent !== 'yes') throw new Error('Please confirm permission to include this greeting in the crew holiday reel.');
  const duration = Number(form.duration);
  if (!Number.isFinite(duration) || duration <= 0 || duration > 15.1) {
    throw new Error('Please choose a video that is 15 seconds or shorter.');
  }
  const requestId = String(form.requestId || '');
  if (!/^[a-f0-9-]{36}$/i.test(requestId)) throw new Error('Please refresh the form and try again.');
  const started = Number(form.startedAt);
  const age = Date.now() - started;
  if (!Number.isFinite(age) || age < 1500 || age > 12 * 60 * 60 * 1000) {
    throw new Error('Please refresh the form before submitting.');
  }
  const video = form.video;
  if (!video || typeof video.getBytes !== 'function') throw new Error('Please choose a video file.');
  const bytes = video.getBytes();
  if (!bytes.length || bytes.length > MAX_VIDEO_BYTES_) throw new Error('Choose a video smaller than 25 MB.');
  const mime = String(video.getContentType() || '').toLowerCase();
  if (!['video/mp4', 'video/quicktime', 'video/webm'].includes(mime)) {
    throw new Error('Please use an MP4, MOV, or WebM video.');
  }
  const signature = bytes.slice(4, 8).map(b => String.fromCharCode(b & 255)).join('');
  const webm = [26, 69, 223, 163].every((b, i) => (bytes[i] & 255) === b);
  if (mime === 'video/webm' ? !webm : !['ftyp', 'moov', 'mdat', 'wide', 'free'].includes(signature)) {
    throw new Error('This file could not be recognized as a supported video.');
  }

  const lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) throw new Error('The upload desk is busy. Please try again in a moment.');
  try {
    const cache = CacheService.getScriptCache();
    const receiptKey = 'receipt-' + requestId;
    const cachedReceipt = cache.get(receiptKey);
    if (cachedReceipt) return JSON.parse(cachedReceipt);
    // Drive's appProperties make retries safe even after the temporary cache expires.
    const existing = Drive.Files.list({
      q: "'" + folderId + "' in parents and trashed = false and appProperties has { key='receipt' and value='" + requestId + "' }",
      fields: 'files(id)', pageSize: 1
    });
    if (existing.files && existing.files.length) return { ok: true, receipt: requestId };

    const props = PropertiesService.getScriptProperties();
    const day = Utilities.formatDate(new Date(), 'America/New_York', 'yyyy-MM-dd');
    const hour = Utilities.formatDate(new Date(), 'America/New_York', 'yyyy-MM-dd-HH');
    const oldUsage = JSON.parse(props.getProperty('UPLOAD_USAGE') || '{}');
    const dailyBytes = oldUsage.day === day ? Number(oldUsage.bytes || 0) : 0;
    const hourlyCount = oldUsage.hour === hour ? Number(oldUsage.count || 0) : 0;
    if (dailyBytes + bytes.length > MAX_DAILY_BYTES_ || hourlyCount >= 100) {
      throw new Error('Video collection is busy today. Please try again later.');
    }
    const extension = mime === 'video/webm' ? 'webm' : mime === 'video/quicktime' ? 'mov' : 'mp4';
    const clean = value => value.replace(/[^a-z0-9_-]+/gi, '_').slice(0, 48);
    const name = day + '_To_' + clean(recipient) + '_From_' + clean(sender) + '_' + requestId.slice(0, 8) + '.' + extension;
    const created = Drive.Files.create({
      name, mimeType: mime, parents: [folderId],
      description: JSON.stringify({ sender, recipient, duration, receivedAt: new Date().toISOString(), consent: 'crew holiday reel' }),
      appProperties: { receipt: requestId }
    }, video.setName(name), { fields: 'id' });
    if (!created.id) throw new Error('The upload was not confirmed. Please try again.');
    props.setProperty('UPLOAD_USAGE', JSON.stringify({ day, bytes: dailyBytes + bytes.length, hour, count: hourlyCount + 1 }));
    const receipt = { ok: true, receipt: requestId };
    cache.put(receiptKey, JSON.stringify(receipt), 21600);
    return receipt;
  } finally {
    lock.releaseLock();
  }
}

const UPLOAD_HTML_ = "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n  <base target=\"_top\">\n  <style>\n    :root{color-scheme:dark;font-family:Arial,sans-serif;background:#050d1c;color:#e2e8f0}\n    *{box-sizing:border-box}body{margin:0;padding:18px}form{max-width:700px;margin:auto}\n    .row{display:grid;grid-template-columns:1fr 1fr;gap:16px}label{display:block;font-size:14px;margin-bottom:7px}\n    input[type=text],input[type=file]{width:100%;font:inherit;color:#fff;background:#0f1b30;border:1px solid #334155;border-radius:12px;padding:12px}\n    input:focus,button:focus{outline:2px solid #6ee7b7;outline-offset:3px}.field{margin-bottom:18px}\n    small{display:block;color:#94a3b8;line-height:1.5;margin-top:8px;font-size:14px}\n    .consent{display:flex;align-items:flex-start;gap:10px;line-height:1.5}.consent input{margin-top:4px}\n    button{font:700 15px Arial;padding:13px 20px;border:0;border-radius:12px;background:#34d399;color:#03291e;cursor:pointer}\n    button:disabled{opacity:.55;cursor:wait}#status{font-size:15px;line-height:1.6;margin-top:16px;min-height:28px}\n    .trap{position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden}.success{color:#6ee7b7}.error{color:#fca5a5}\n    @media(max-width:520px){.row{grid-template-columns:1fr;gap:0}body{padding:12px}}\n  </style>\n</head>\n<body>\n<form id=\"upload-form\">\n  <div class=\"row\">\n    <div class=\"field\"><label for=\"sender\">From (your name or family)</label><input id=\"sender\" name=\"sender\" type=\"text\" maxlength=\"100\" required placeholder=\"The Miller Family\" autocomplete=\"name\"></div>\n    <div class=\"field\"><label for=\"recipient\">To (sailor or whole boat)</label><input id=\"recipient\" name=\"recipient\" type=\"text\" maxlength=\"100\" placeholder=\"Whole Boat — Blue Crew\"></div>\n  </div>\n  <div class=\"field\"><label for=\"video\">Your holiday video</label><input id=\"video\" name=\"video\" type=\"file\" accept=\"video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm\" required><small>MP4, MOV, or WebM • 15 seconds or shorter • up to 25 MB. Nothing is saved in your browser.</small></div>\n  <label class=\"consent\"><input id=\"consent\" name=\"consent\" type=\"checkbox\" value=\"yes\" required><span>I have permission to share this video and agree that it may be included in the Blue Crew holiday reel.</span></label>\n  <div class=\"trap\" aria-hidden=\"true\"><label>Website<input name=\"website\" type=\"text\" tabindex=\"-1\" autocomplete=\"off\"></label></div>\n  <input type=\"hidden\" id=\"duration\" name=\"duration\"><input type=\"hidden\" id=\"requestId\" name=\"requestId\"><input type=\"hidden\" id=\"startedAt\" name=\"startedAt\">\n  <p><button id=\"submit\" type=\"submit\">Send private video greeting</button></p>\n  <div id=\"status\" role=\"status\" aria-live=\"polite\">Your video goes directly to the organizer’s private Google Drive folder. Other visitors cannot browse submissions.</div>\n</form>\n<script>\n  const form = document.getElementById('upload-form');\n  const input = document.getElementById('video');\n  const status = document.getElementById('status');\n  const button = document.getElementById('submit');\n  let ready = false;\n  let selection = 0;\n  function resetReceipt() {\n    document.getElementById('requestId').value = crypto.randomUUID();\n    document.getElementById('startedAt').value = Date.now();\n  }\n  function message(text, type) { status.textContent = text; status.className = type || ''; }\n  resetReceipt();\n  input.addEventListener('change', () => {\n    ready = false;\n    const version = ++selection;\n    document.getElementById('duration').value = '';\n    resetReceipt();\n    const file = input.files[0];\n    if (!file) return;\n    if (file.size > 25 * 1024 * 1024) { message('Please choose a video smaller than 25 MB.', 'error'); input.value = ''; return; }\n    message('Checking your video…');\n    const video = document.createElement('video');\n    const url = URL.createObjectURL(file);\n    video.preload = 'metadata';\n    video.onloadedmetadata = () => {\n      URL.revokeObjectURL(url);\n      if (selection !== version) return;\n      if (!Number.isFinite(video.duration) || video.duration <= 0 || video.duration > 15.1) {\n        message('This clip is longer than 15 seconds. Please trim it and choose it again.', 'error'); input.value = ''; return;\n      }\n      document.getElementById('duration').value = video.duration;\n      ready = true;\n      message('Ready: ' + file.name + ' (' + video.duration.toFixed(1) + ' seconds).', 'success');\n    };\n    video.onerror = () => { URL.revokeObjectURL(url); if (selection === version) { input.value = ''; message('This video cannot be read. Try an MP4, MOV, or WebM file.', 'error'); } };\n    video.src = url;\n  });\n  form.addEventListener('submit', event => {\n    event.preventDefault();\n    if (!ready) { message('Choose a supported video that is 15 seconds or shorter.', 'error'); return; }\n    if (!form.reportValidity()) return;\n    button.disabled = true;\n    message('Sending your greeting… Please keep this page open until you receive confirmation.');\n    google.script.run.withSuccessHandler(result => {\n      button.disabled = false;\n      if (!result || result.ok !== true) { message('The upload was not confirmed. Please try again.', 'error'); return; }\n      message('Thank you! Your greeting was received. Receipt: ' + result.receipt.slice(0, 8), 'success');\n      form.reset(); ready = false; resetReceipt();\n    }).withFailureHandler(error => {\n      button.disabled = false;\n      message(error.message || 'Your upload could not be confirmed. Please try again.', 'error');\n    }).uploadGreeting(form);\n  });\n</script>\n</body>\n</html>\n";
